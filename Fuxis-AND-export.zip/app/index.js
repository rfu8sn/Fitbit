// Version 1.6b - include settings
// Erweitert um Sekunden - Anzeige und Jahr  Roland Fux

import clock from "clock";
import document from "document";
import { preferences } from "user-settings";
import { units } from "user-settings";
import { getDisplayMonth, getDisplayDay, zeroPad, calculateDistance, round} from "../common/utils";
import { battery } from "power";
import userActivity from "user-activity"; //adjusted types
import { goals} from "user-activity";
import * as hrm from "./hrm";

//import for settings
import { inbox } from "file-transfer";
import { readFileSync } from "fs";
import * as cbor from 'cbor';
import { user } from "user-profile";

let defaultSettings = {
  timeColor: "cyan",
  textColor: '#FFFFFF',
  backgroundColor: "black"
};
let settings = defaultSettings;


// HR Icon animation
hrm.initialize();

// RuhePuls auslesen
const restingHeartRateValue = user.restingHeartRate;

//initialization settings
inbox.onnewfile = processInbox;

// Update the clock every seconds  --> display hours:minutes:seconds
clock.granularity = "seconds";

// Get a handle on the <text> element
const backgroundHandle = document.getElementById("background");
const timeHandle = document.getElementById("timeLabel");
const timeHandle12 = document.getElementById("timeLabel12");
const secondHandle = document.getElementById("secondLabel");
const dayHandle = document.getElementById("dayLabel");
const dateHandle = document.getElementById("dateLabel");
const batteryHandle = document.getElementById("batteryLabel");
const stepsHandle = document.getElementById("stepsLabel");
const caloriesHandle = document.getElementById("caloriesLabel");
const activeMinutesHandle = document.getElementById("activeminutesLabel");
const floorsHandle = document.getElementById("floorsLabel");
const distanceHandle = document.getElementById("distanceLabel");
const heartrateHandle = document.getElementById("heartrateLabel");
const heartrateHandle = document.getElementById("heartrateLabel");
const restingHeartRateHandle = document.getElementById("restingHeartRateLabel");

// Get a handle on the <icon> elements
const steps_iconHandle = document.getElementById('steps_icon');
const floors_iconHandle = document.getElementById('floors_icon');
const distance_iconHandle = document.getElementById('distance_icon');
const activeMinutes_iconHandle = document.getElementById('activeminutes_icon');
const calories_iconHandle = document.getElementById('cals_icon');
const battery_iconHandle = document.getElementById('battery_icon');

// Import clock preference (12h or 24h format)
const clockPref = preferences.clockDisplay;

// Import measure units 
const measureUnitsPref = units.distance;

// Import goals
const stepsGoal = goals.steps;
const floorsGoal = goals.elevationGain;
const distanceGoal = goals.distance;
const caloriesGoal = goals.calories;
const activeMinutesGoal = goals.activeMinutes;


// Define metrics
const metricSteps = "steps";
const metricCalories = "calories";
const metricDistance = "distance";
const metricActiveMinutes = "activeMinutes";
const metricFloors = "elevationGain";

// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  const batteryValue = battery.chargeLevel; // Battery Measurement
  const now = evt.date;
  const minsZeroed;
  const secZeroed;
  const antipost;
  const hours = now.getHours();
  const mins = now.getMinutes();
  const sec = now.getSeconds();
  
  if (clockPref === "12h") {
    // 12h format
    hours = hours % 12 || 12;   
    minsZeroed = zeroPad(2,mins);
    secZeroed = zeroPad(2,sec);
    
    if (now.getHours() <12) {
      antipost = 'am';
    } else
      {antipost = 'pm';
    }
    minsZeroed = zeroPad(mins);
    secZeroed = zeroPad(sec);
    timeHandle.text = "";
    timeHandle12.text = `${hours}:${minsZeroed}`;
    secondHandle.text = " " + `:${secZeroed}` + " " + antipost;
    }
    else {
      // 24h format
    hours = zeroPad(hours);
    minsZeroed = zeroPad(mins);
    secZeroed = zeroPad(sec);
    timeHandle.text = `${hours}:${minsZeroed}`; //:${secZeroed}`;
    secondHandle.text = " " + `:${secZeroed}`
    }

    
  let day = now.getDay(); // this shows the day of the week from 0 to 6
  let month = now.getMonth(); // this shows the month number from 0 to 11
  let year = 1900 + now.getYear(); // this shows the year
  const dayOfMonth = now.getDate(); // this shows the day of the month from 1 to 30 (or 28 or 31)
  
  const displayMonth = getDisplayMonth(month);
  const displayDay = getDisplayDay(day);
  
  const dayValue = `${displayDay}`;
  const dateValue = `${dayOfMonth} ${displayMonth}`;
  
  // Activity Values: adjusted type
  let stepsValue = (userActivity.today.adjusted[metricSteps] || 0);
  if (stepsValue === 1){
    let stepsString = stepsValue + '  Schritt';
  }
  else{
    let stepsString = stepsValue + '  Schritte';
  }
  
  let caloriesValue = (userActivity.today.adjusted[metricCalories] || 0);
  if (caloriesValue === 1){
    let caloriesString = caloriesValue + '  Kalorie';
  }
  else{
    let caloriesString = caloriesValue + '  Kalorien';
  }
  
  let floorsValue = userActivity.today.adjusted[metricFloors];
  if (floorsValue === 1){
    let floorsString = floorsValue + '  Stockwerk';
  }
  else{
    let floorsString = floorsValue + '  Stockwerke';
  }
  
  let activeMinutesValue = userActivity.today.adjusted[metricActiveMinutes];
  let activeMinutesString = activeMinutesValue + '  min';
  let distanceValueFromDevice = userActivity.today.adjusted[metricDistance];
  let distanceValue;
  let distanceMeasure;
  if (measureUnitsPref === 'us') {
    distanceValue = Math.round(distanceValueFromDevice * 0.00062137*100, 2)/100;
    distanceMeasure = '  mi';
    } else {
    distanceValue = Math.round(distanceValueFromDevice / 10, 2)/100;
    distanceMeasure = '  km';
    }
  let distanceString = distanceValue + distanceMeasure;
  
  // Assignment values
  dayHandle.text = `${displayDay}`;
  dateHandle.text = `${dayOfMonth}.  ${displayMonth}  ${year}`;
  batteryHandle.text = batteryValue + '  %'; 
  stepsHandle.text = stepsString;
  floorsHandle.text = floorsString;
  distanceHandle.text = distanceString;
  activeMinutesHandle.text = activeMinutesString;
  caloriesHandle.text = caloriesString;
  restingHeartRateHandle.text = "( " + restingHeartRateValue + " BPM )";
  
  
  
    // Check if goals met
    battery_iconHandle.style.fill = settings.timeColor;

   
  if (stepsValue > stepsGoal) {
    steps_iconHandle.style.fill = "lightgreen"; //settings.timeColor;
    } else {
    steps_iconHandle.style.fill = settings.textColor;
    }


  if (floorsValue > floorsGoal) {
    floors_iconHandle.style.fill = "lightgreen"; //settings.timeColor;
    } else {
    floors_iconHandle.style.fill = settings.textColor ;
    }

  if (distanceValueFromDevice > distanceGoal) {  
     distance_iconHandle.style.fill = "lightgreen"; //settings.timeColor;
    } else {
    distance_iconHandle.style.fill = settings.textColor ;
    }

  if (caloriesValue > caloriesGoal) {
    calories_iconHandle.style.fill = "lightgreen"; //settings.timeColor;
    } else {
    calories_iconHandle.style.fill = settings.textColor ;
    }

if (activeMinutesValue > activeMinutesGoal) {
    activeMinutes_iconHandle.style.fill = "lightgreen"; //settings.timeColor;
    } else {
    activeMinutes_iconHandle.style.fill = settings.textColor ;
    }
}


//settings handling
function loadSettings()
{
  try {
    settings = readFileSync("settings.cbor", "cbor");
    mergeWithDefaultSettings();
  } catch (e) {
    console.log('No settings found, fresh install, applying default settings...');
    
    //apply default settings
    settings = defaultSettings;
  }
  
  console.log('Applying settings: ' + JSON.stringify(settings));
  applySettings();
}


function mergeWithDefaultSettings() {
  for (let key in defaultSettings) {
    if (!settings.hasOwnProperty(key)) {
      settings[key] = defaultSettings[key];
    }
  }
}

function applySettings() {
  backgroundHandle.style.fill = settings.backgroundColor;
  timeHandle.style.fill = settings.timeColor;
  //dateHandle.style.fill = settings.textColor;
  batteryHandle.style.fill = settings.textColor;
  stepsHandle.style.fill = settings.textColor;
  caloriesHandle.style.fill = settings.textColor;
  activeMinutesHandle.style.fill = settings.textColor;
  distanceHandle.style.fill = settings.textColor;
  floorsHandle.style.fill = settings.textColor;
  timeHandle.style.fill = settings.timeColor;
  steps_iconHandle.style.fill = settings.textColor;
  calories_iconHandle.style.fill = settings.textColor; 
  floors_iconHandle.style.fill = settings.textColor;
  distance_iconHandle.style.fill = settings.textColor;
  activeMinutes_iconHandle.style.fill = settings.textColor;
    
}


//load stored settings if any at startup
loadSettings();

function processInbox()
{
  let fileName;
  while (fileName = inbox.nextFile()) {
    console.log("File received: " + fileName);

    if (fileName === 'settings.cbor') {
        loadSettings();
    }
  }

};


