// Add zero in front of numbers < 10
export function zeroPad(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}

export function getDisplayDay(day) {
  const strDays = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  return strDays[day];
}

export function getDisplayMonth(month) {
  const strMonth = ["Januar", "Februr", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
  return strMonth[month];
}

export function calculateDistance(distance, unitType) {
  if (unitType === 'us') {
    return `${round((distance * 0.00062137), 2)}`
  } else {
    return `${round(distance/1000, 2)}`
  }
}